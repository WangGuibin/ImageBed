//
//  ViewController.swift
//  DownloadZipDemo
//
//  Created by 王贵彬 on 2025/2/12.
//

import UIKit
import Alamofire


class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let headers : HTTPHeaders = [
            "Accept": "application/json"
        ];
        APIClient.shared.get(url: "https://httpbin.org/get", headers: headers) { response in
            if response.isSuccess {
                print("GET请求成功\(String(describing: response.value))")
            }else{
                print("GET请求失败\(response.error?.localizedDescription ?? "xxxx未知错误")")
            }
        }
        
        
        APIClient.shared.post(url: "https://httpbin.org/post",parameters: ["abc" : "12345 nice"], headers: headers) { response in
            if response.isSuccess {
                print("POST请求成功\(String(describing: response.value))")
            }else{
                print("POST请求失败\(response.error?.localizedDescription ?? "xxxx未知错误")")
            }
        }

        
        let zipURL = "https://github.com/WangGuibin/webserver-cli/archive/refs/heads/main.zip"
        let destination : DownloadRequest.DownloadFileDestination = {_,_ in
            let documentsURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            let fileURL = documentsURL.appendingPathComponent( "myZip.zip")
            return (fileURL,[.removePreviousFile,.createIntermediateDirectories])
        }
        
        Alamofire.download(zipURL, to: destination).response { response in
            debugPrint(response)
            if response.error == nil , let filePath = response.destinationURL?.path{
                print("zip文件下载成功 \(filePath)")
            }else{
                print("zip文件下载失败 \(response.error?.localizedDescription ?? "未知错误" )")
            }
        }
        
        
    }

}

