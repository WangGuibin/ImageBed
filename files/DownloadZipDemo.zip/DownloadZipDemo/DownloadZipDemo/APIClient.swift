//
//  APIClient.swift
//  DownloadZipDemo
//
//  Created by 王贵彬 on 2025/2/12.
//

import Foundation
import Alamofire


class APIClient {
    
    static let shared = APIClient()
    private init() {}
    
    
    func get (url: String , parameters: [String:Any]? = nil, headers: HTTPHeaders?, completion:@escaping (Result<Any>)-> Void){
        Alamofire.request(url,method: .get, parameters: parameters,encoding: URLEncoding.default, headers: headers)
            .validate()
            .responseJSON { response in
                switch response.result {
                case .success(let value):
                    if let json = value as? [String: Any] {
                        completion(.success(json))
                    }else{
                        completion(.failure(NSError(domain: "json invalid", code: 0, userInfo: nil)))
                    }
                case .failure(let error):
                    completion(.failure(error))
                }
            }
    }
    
    
    func post (url: String , parameters: [String:Any]? = nil, headers: HTTPHeaders?, completion:@escaping (Result<Any>)-> Void){
        Alamofire.request(url,method: .post, parameters: parameters,encoding: URLEncoding.default, headers: headers)
            .validate()
            .responseJSON { response in
                switch response.result {
                case .success(let value):
                    if let json = value as? [String: Any] {
                        completion(.success(json))
                    }else{
                        completion(.failure(NSError(domain: "json invalid", code: 0, userInfo: nil)))
                    }
                case .failure(let error):
                    completion(.failure(error))
                }
            }
    }
    
}
